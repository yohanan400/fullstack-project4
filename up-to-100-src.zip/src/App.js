
import React, { Component } from 'react';
import Register from './Register';


export default class App extends Component {
  constructor(props) {
    super();
  }

  render() {
    return (
      <div className="App">
        <Register />
      </div>
    );
  }
}

